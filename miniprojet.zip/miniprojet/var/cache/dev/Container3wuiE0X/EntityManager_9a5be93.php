<?php

namespace Container3wuiE0X;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/src/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder51bec = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerc938b = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties8c76c = [
        
    ];

    public function getConnection()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getConnection', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getMetadataFactory', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getExpressionBuilder', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'beginTransaction', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getCache', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getCache();
    }

    public function transactional($func)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'transactional', array('func' => $func), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'wrapInTransaction', array('func' => $func), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'commit', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->commit();
    }

    public function rollback()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'rollback', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getClassMetadata', array('className' => $className), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'createQuery', array('dql' => $dql), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'createNamedQuery', array('name' => $name), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'createQueryBuilder', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'flush', array('entity' => $entity), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'clear', array('entityName' => $entityName), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->clear($entityName);
    }

    public function close()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'close', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->close();
    }

    public function persist($entity)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'persist', array('entity' => $entity), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'remove', array('entity' => $entity), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->remove($entity);
    }

    public function refresh($entity, ?int $lockMode = null)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'refresh', array('entity' => $entity, 'lockMode' => $lockMode), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->refresh($entity, $lockMode);
    }

    public function detach($entity)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'detach', array('entity' => $entity), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'merge', array('entity' => $entity), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getRepository', array('entityName' => $entityName), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'contains', array('entity' => $entity), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getEventManager', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getConfiguration', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'isOpen', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getUnitOfWork', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getProxyFactory', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'initializeObject', array('obj' => $obj), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'getFilters', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'isFiltersStateClean', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'hasFilters', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return $this->valueHolder51bec->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerc938b = $initializer;

        return $instance;
    }

    public function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, ?\Doctrine\Common\EventManager $eventManager = null)
    {
        static $reflection;

        if (! $this->valueHolder51bec) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder51bec = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder51bec->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, '__get', ['name' => $name], $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        if (isset(self::$publicProperties8c76c[$name])) {
            return $this->valueHolder51bec->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder51bec;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder51bec;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder51bec;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder51bec;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, '__isset', array('name' => $name), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder51bec;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder51bec;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, '__unset', array('name' => $name), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder51bec;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder51bec;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, '__clone', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        $this->valueHolder51bec = clone $this->valueHolder51bec;
    }

    public function __sleep()
    {
        $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, '__sleep', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;

        return array('valueHolder51bec');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerc938b = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerc938b;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerc938b && ($this->initializerc938b->__invoke($valueHolder51bec, $this, 'initializeProxy', array(), $this->initializerc938b) || 1) && $this->valueHolder51bec = $valueHolder51bec;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder51bec;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder51bec;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
